from setuptools import setup

setup(
	name='definexpfam',
	version='1.0',
	packages=['definexpfam'],
	url='https://github.com/zhoucx1119/definexpfam',
	license='',
	author='Chenxi Zhou',
	author_email='zhoucx1989@gmail.com',
	description='Density estimation in finite-dimensional exponential families '
)
